<?php
session_start();


$return_url = isset($_GET['return_url']) ? $_GET['return_url'] : '';


if (!empty($_SESSION['logged_in'])) {
    if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'client') {
        if (!empty($return_url)) {
            header("Location: " . urldecode($return_url));
            exit;
        }else{
            header("location:user/dashboard/dashboard.php");
        }
        exit;
    }
}



include("includes/connections.php");


if (isset($_POST['forgot_submit'])) {

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $forgot_username = $_POST['forgot_username'];
        if (!empty($forgot_username)) {
            $query = "select * from users where email = '$forgot_username' limit 1";
            $result = mysqli_query($con, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $recover_email = $row['email'];





                //


                $c = 5;
                function getChar($c)
                {
                    $characters = 'abcdefghijklmnopqrstuvwxyz';
                    $randomString = '';

                    for ($i = 0; $i < $c; $i++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
                    return $randomString;
                }
                $s = 1;
                function getSpec($s)
                {
                    $characters = '$%&*@#?>';
                    $randomString = '';

                    for ($i = 0; $i < $s; $i++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
                    return $randomString;
                }
                $u = 1;
                function getUpp($u)
                {
                    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $randomString = '';

                    for ($i = 0; $i < $u; $i++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
                    return $randomString;
                }
                $num = 1;
                function getNumber($num)
                {
                    $characters = '1234567890';
                    $randomString = '';

                    for ($i = 0; $i < $num; $i++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
                    return $randomString;
                }
                $characters8 = getChar($c);
                $special1 = getSpec($s);
                $upper1 = getUpp($u);
                $number1 = getNumber($num);


                $recover_password = $special1 . "" . $upper1 . "" . $characters8 . "" . $number1;


                $newpassword = password_hash($recover_password, PASSWORD_DEFAULT);

                //



                $sqlf = "UPDATE users SET password='$newpassword' WHERE email = '$forgot_username'";
                $resultf = mysqli_query($con, $sqlf);






                $subject = "Account recovery";
                $message = "Account Information: <br>Email Address: " . $recover_email . "<br>Password: " . $recover_password;
                include("login/send-recovery.php");
                echo '<script>alert("Your account information has sent to your email!");
                document.location.href="index.php";</script>';
            }
        }
    }
}


?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <link rel="stylesheet" href="links/bootstrap-5.3/css/bootstrap.min.css">
    <link rel='stylesheet' href='links/font/montserrat.css'>
    <link rel="stylesheet" href="links/login/style.css">
    <link rel='stylesheet' href='links/icon/remixicon.css'>
</head>
<style>
    .invalid:hover,
    .invalid:focus {
        border: solid .5px darkred;
    }

    body {
        background: url('files/bg.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        background-blend-mode: overlay;
        background-color: rgba(0, 0, 0, .85);
    }
</style>

<body>
    <!-- Partial -->

    <div class="login-container">
        <!-- login card -->
        <div id="login-card">

            <h4 class="login__title">LOGIN</h4>
            <form id="login-form" class="form-login">
                <label for="login-input-user" class="login__label">
                    email
                </label>

                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="ri-user-4-line"></i></span>
                    <input id="login-input-user" autocomplete="off" required name="login_username" class="login__input form-control focus-ring focus-ring-light" type="text" />
                </div>

                <input type="hidden" name="return_url" value="<?= htmlspecialchars($return_url) ?>">


                <label for="login-input-password" class="login__label">
                    Password
                </label>

                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="ri-lock-password-line"></i></span>
                    <input id="login-input-password" name="login_password" required class="login__input form-control focus-ring focus-ring-light" type="password" />


                    <span class="input-group-text" style="cursor: pointer;" onclick="password_show_hide();">
                        <i class="ri-eye-off-line" id="show_eye"></i>
                        <i class="ri-eye-line d-none" id="hide_eye"></i>
                    </span>

                </div>


                <div id="invalid" class="d-none">
                    <span style="margin-top: .5em; color:orange;" class="login__label">invalid username or password</span>
                </div>
                <div id="login_button">
                    <input type="submit" class="login__submit" value="login">
                </div>
                <div id="login_loading" class="d-none">
                    <button disabled type="submit" class="login__loading">
                        <li class="fa-solid fa-circle-notch fa-spin"></li>
                    </button>
                </div>
                <div id="login_success" class="d-none">
                    <button disabled type="submit" class="login__success">
                        <li class="fa-regular fa-circle-check"></li>&nbsp;login successfully
                    </button>
                </div>
            </form>
            <a href="#" id="forgot_password" class="login__forgot">Forgot Password?</a>

        </div>
        <!-- login card -->

        <!-- forgot card -->
        <div id="forgot-card" class="d-none">

            <h4 class="forgot__title">Recover Account</h4>
            <h4 class="forgot__title" style="color:#fff;opacity:.8; font-size:10px; margin:0px 0px 12px 0px; font-weight:100">RESET PASSWORD</h4>
            <form id="forgot-form" method="POST" class="form-login">
                <label for="login-input-user" class="login__label">
                    email
                </label>
                <input id="login-input-user" autocomplete="off" required name="forgot_username" class="login__input" type="text" />

                <div id="invalid" class="d-none">
                    <span style="margin-top: .5em; color:orange;" class="login__label">invalid email or password</span>
                </div>
                <div id="login_button">
                    <input type="submit" class="login__submit" name="forgot_submit" value="email account recovery">
                </div>
                <div class="btn_cancel">
                    <button id="forgot_cancel" class="forgot__cancel">Cancel</button>
                </div>
                <div id="login_loading" class="d-none">
                    <button disabled type="submit" class="login__loading">
                        <li class="fa-solid fa-circle-notch fa-spin"></li>
                    </button>
                </div>
                <div id="login_success" class="d-none">
                    <button disabled type="submit" class="login__success">
                        <li class="fa-regular fa-circle-check"></li>&nbsp;login successfully
                    </button>
                </div>
            </form>
        </div>
        <!-- forgot card -->
    </div>

    <!-- partial -->




    <script src="links/bootstrap-5.3/js/bootstrap.min.js"></script>
    <script src="links/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/be0c9622b4.js" crossorigin="anonymous"></script>
</body>


<script>
    function password_show_hide() {
        var x = document.getElementById("login-input-password");
        var show_eye = document.getElementById("show_eye");
        var hide_eye = document.getElementById("hide_eye");
        hide_eye.classList.remove("d-none");
        if (x.type === "password") {
            x.type = "text";
            show_eye.style.display = "none";
            hide_eye.style.display = "block";
        } else {
            x.type = "password";
            show_eye.style.display = "block";
            hide_eye.style.display = "none";
        }
    }
</script>

<script>
    $(document).ready(function() {

        $("#forgot_password").click(function() {
            $("#forgot-card").removeClass("d-none");
            $("#login-card").addClass("d-none");
            $("#login_username").val();
            $("#login_password").val();
        });

        $("#forgot_cancel").click(function() {
            $("#forgot-card").addClass("d-none");
            $("#login-card").removeClass("d-none");
            $("#forgot_username").val();
        });
    });
</script>
<script>
    $(document).on('submit', '#login-form', function(e) {
        e.preventDefault();

        var formData = new FormData(this);
        formData.append("login-submit", true);

        $.ajax({
            type: "POST",
            url: "login/ajax.php",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                var res = jQuery.parseJSON(response);
                if (res.status == 100) {
                    $('#login-input-user').removeClass('invalid');
                    $('#login-input-password').removeClass('invalid');
                    $('#invalid').addClass('d-none');
                    $('#login_button').addClass('d-none');
                    $('#login_loading').removeClass('d-none');
                    setTimeout(function() {
                        $('#login_loading').addClass('d-none');
                        $('#login_success').removeClass('d-none');
                        setTimeout(function() {
                            location.assign("admin/dashboard/dashboard.php");
                        }, 1000);
                    }, 500);

                } else if (res.status == 99) {
                    $('#login-input-user').removeClass('invalid');
                    $('#login-input-password').removeClass('invalid');
                    $('#invalid').addClass('d-none');
                    $('#login_button').addClass('d-none');
                    $('#login_loading').removeClass('d-none');
                    setTimeout(function() {
                        $('#login_loading').addClass('d-none');
                        $('#login_success').removeClass('d-none');
                        setTimeout(function() {
                            var redirectUrl = res.return_url ? decodeURIComponent(res.return_url) : "user/dashboard/dashboard.php";
                          
                                location.assign(redirectUrl);
                        
                        }, 1000);
                    }, 500);

                } else if (res.status == 101) {
                    $('#login-input-user').removeClass('invalid');
                    $('#login-input-password').removeClass('invalid');
                    $('#login_button').addClass('d-none');
                    $('#login_loading').removeClass('d-none');
                    setTimeout(function() {
                        $('#login-input-user').addClass('invalid');
                        $('#login-input-password').addClass('invalid');
                        $('#login_button').removeClass('d-none');
                        $('#invalid').removeClass('d-none');
                        $('#login_loading').addClass('d-none');
                    }, 500);

                }
            }
        });

    });
</script>

</html>