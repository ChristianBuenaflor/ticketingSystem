<?php
include('../../includes/connections.php');

// Check if task ID and new status are provided
if (isset($_POST['task_id'], $_POST['new_status'])) {
    // Sanitize inputs to prevent SQL injection
    $taskId = mysqli_real_escape_string($con, $_POST['task_id']);
    $newStatus = mysqli_real_escape_string($con, $_POST['new_status']);
    $draggedBy = mysqli_real_escape_string($con, $_POST['dragged_by']);

    // Update task status in the database


    

    $qoldstatus = "SELECT * FROM projects_task WHERE task_id = $taskId";
$roldstatus = mysqli_query($con, $qoldstatus);
if (mysqli_num_rows($roldstatus) > 0) {
  while ($rowoldstatus = $roldstatus->fetch_assoc()) {
    $old_status = $rowoldstatus['status'];
  }
}

    if($newStatus != $old_status)
    {
        $description = 'Moved this card from '.$old_status;

        date_default_timezone_set('Asia/Manila');
        $date_stamp = date("m/d/Y h:i a");
    
        $queryCom = "INSERT INTO task_comments (task_id, user_id, description, date_stamp) 
                  VALUES ('$taskId', '$draggedBy', '$description', '$date_stamp')";
        $resultCom = mysqli_query($con, $queryCom);
    }

 



    $query = "UPDATE projects_task SET status = '$newStatus' WHERE task_id = '$taskId'";
    $result = mysqli_query($con, $query);

    // Check if the query was successful
    if ($result) {
        echo "Task status updated successfully!";
    } else {
        echo "Error updating task status!";
    }
} else {
    echo "Task ID or new status not provided!";
}
