<?php

$dbhost = "localhost";
$dbuser = "u673355866_ticketing";
$dbpass = "1a#1%324gfSdR5&341f";
$dbname = "u673355866_ticketing";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{
	die("failed to connect!");
}
