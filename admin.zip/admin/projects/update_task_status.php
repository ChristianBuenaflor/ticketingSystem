<?php
include('../../includes/connections.php');

// Check if task ID and new status are provided
if(isset($_POST['task_id'], $_POST['new_status'])) {
    // Sanitize inputs to prevent SQL injection
    $taskId = mysqli_real_escape_string($con, $_POST['task_id']);
    $newStatus = mysqli_real_escape_string($con, $_POST['new_status']);
    
    // Update task status in the database
    $query = "UPDATE projects_task SET status = '$newStatus' WHERE task_id = '$taskId'";
    $result = mysqli_query($con, $query);

    // Check if the query was successful
    if($result) {
        echo "Task status updated successfully!";
    } else {
        echo "Error updating task status!";
    }
} else {
    echo "Task ID or new status not provided!";
}
?>
